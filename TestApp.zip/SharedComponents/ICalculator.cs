﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharedComponents
{
    public interface ICalculator
    {
        int Divide(int numerator, int denominator);
    }
}
