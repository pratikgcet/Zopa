﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharedComponents
{
    public class Calculator : ICalculator
    {

        public int Divide(int numerator, int denominator)
        {
            try
            {
                return numerator/denominator;
            }
            catch (Exception exception)
            {
                throw exception;

            }
        }
    }
}
