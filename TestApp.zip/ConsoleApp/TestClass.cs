﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp
{
    public class TestClass
    {
        public static void Main()
        {
            Console.WriteLine(PrintFizzBuzz());
            Console.ReadLine();
        }

        public static string PrintFizzBuzz()
        {
            string myFizzString = "";
            for (int i = 1; i <101; i++)
            {
                if (i % 3 == 0)
                    myFizzString += "Fizz" + Environment.NewLine;
                else if (i % 5 == 0)
                    myFizzString += "Buzz" + Environment.NewLine;
                else
                    myFizzString += i + Environment.NewLine;
            }
            return myFizzString;
        }
        
    }
}
